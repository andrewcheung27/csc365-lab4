# CSC 365 Lab 4 - Simple Queries

## Author: Andrew Cheung
## Email: acheun29@calpoly.edu
